package gmailnotification;

/**
 *
 * @author Eyosias
 */
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.Scanner;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
public class News {
    public static void getNews() throws JSONException {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Desta Langena\\Documents\\NetBeansProjects\\GmailNotification\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://addisfortune.net/");
        //List <WebElement> allLinks = driver.findElement(By.className("span6")).findElements(By.tagName("h3"));
        WebElement link = driver.findElement(By.className("span6")).findElement(By.tagName("h3")).findElement(By.tagName("a"));
        List <WebElement> allTitles = driver.findElement(By.className("span6")).findElements(By.tagName("h3"));
        List <WebElement> allParagraphs = driver.findElement(By.className("span6")).findElements(By.tagName("p"));
        List <WebElement> allImagesSrc = driver.findElement(By.className("span6")).findElements(By.className("span2"));
        
        JSONObject obj = new JSONObject();
        JSONArray list = new JSONArray();
        for(int i = 0; i < allTitles.size(); i++) {
            obj.put("header", allTitles.get(i).getText().toString());
            obj.put("paragraph", allParagraphs.get(i).getText().toString());
            list.put(obj);
            try (FileWriter file = new FileWriter("C:\\Users\\Desta Langena\\Desktop\\writeJson.json")) {
        file.write(list.toString());
        file.flush();
    } catch(IOException e) {
        e.printStackTrace();
    }
        }
    
    System.out.println(obj);
        //String getLink = link.getAttribute("href");
        //String getLink = link.getText();
        //driver.get(getLink);
        //WebElement linkTwo = driver.findElement(By.id("newsarticletext")).findElement(By.tagName("p"));
        //System.out.println(linkTwo);
        //System.out.println("The wrds and links are");
        for(int i = 0; i < 15; i++) {
        System.out.println( allTitles.get(i).getText().toString());
        System.out.println(allParagraphs.get(i).getText().toString());
        System.out.println("******************");
        System.out.println(allImagesSrc.get(i).getText().toString());
        System.out.println("******************");
        
        
        //System.out.println(allLinks.get(i).getText().toString());
        try {
            Thread.sleep(50);
        } catch(Exception e) {
            driver.close();
        }
                
        }
        try {
            Thread.sleep(50);
        } catch(Exception e) {
            driver.close();
        }
    }
    
    
}
