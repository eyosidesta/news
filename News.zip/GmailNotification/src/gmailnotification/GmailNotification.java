
package gmailnotification;

import java.util.Scanner;
import org.json.JSONException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class GmailNotification {

    public static void notifyFacebook() {
        final int zero = 0;
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Desta Langena\\Documents\\NetBeansProjects\\GmailNotification\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.facebook.com");
        WebElement email = driver.findElement(By.id("email"));
        WebElement pass = driver.findElement(By.id("pass"));
        WebElement login = driver.findElement(By.id("u_0_2"));
        System.out.println("Enter your email or phone number here: ");
        
        Scanner enterEmail = new Scanner(System.in);
        String getEmail = enterEmail.next();
        email.sendKeys(getEmail);
        System.out.println("Enter password here: ");
        Scanner enterPassword = new Scanner(System.in);
        String getPass = enterPassword.next();
        pass.sendKeys(getPass);
        
        login.submit();
        WebElement notification = driver.findElement(By.id("notificationsCountValue"));
        WebElement message = driver.findElement(By.id("mercurymessagesCountValue"));
        WebElement friendRequest = driver.findElement(By.id("requestsCountValue"));
        if (notification != null) {
            
            System.out.println("Number of notification is " + notification.getText().toString());
        }
        else {
            System.out.println("Number of notification is " + zero);
        }
        if(friendRequest != null) {
            System.out.println("Number of friendReuests you have is " + friendRequest.getText().toString());
        }
        else {
            System.out.println("Number of friendReuests you have is " + zero);
            
        }
        if (message != null) {
            System.out.println("Number of messages you have is: " + message.getText().toString());
        }
        else {
            System.out.println("Number of messages you have is: " + zero);
            
        }
        try {
            Thread.sleep(50);
        } catch(Exception e) {
            login.clear();
            driver.close();
        }

    }
    public static void main(String[] args) throws JSONException {
        // TODO code application logic here
        //notifyFacebook();
        News.getNews();
    }
    
}
